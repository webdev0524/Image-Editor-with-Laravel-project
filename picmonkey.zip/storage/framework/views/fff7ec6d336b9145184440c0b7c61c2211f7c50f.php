<!DOCTYPE html>
<html>
<head>
    <title>Welcome Email</title>
</head>

    <body>
        <h2>Welcome to the site </h2>
        <br/>
        Your registered email-id is <?php echo e($user['email']); ?> , Please click on the below link to change your password
        <br/>
        <a href="<?php echo e(route('user.change-password', ["token" => $user->token])); ?>">Change Password</a>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\Drebakare\PicMonkey\resources\views/Emails/change-password.blade.php ENDPATH**/ ?>